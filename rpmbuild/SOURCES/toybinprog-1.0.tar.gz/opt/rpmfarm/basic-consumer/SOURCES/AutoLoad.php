<?php 
/**
*/
require('./class/Bubble.php');
require('./class/CallPortail.php');
require('./class/Vm.php');
require('./class/Docker.php');
require('class/CallRabbit.php');
echo "Load Sucess";
?> 
